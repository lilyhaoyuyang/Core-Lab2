/* jshint esversion:6 */
 //create the particle system by class
class Particle {
  constructor(image) {
    this.image = image;
    this.totalFrame = image.length;
    this.curFrame = round(random(0, this.totalFrame));
  }
// show particle 
  show() {
    if (frameCount % 3 === 0) {
      this.curFrame ++;
    }
    let ser = serRound(this.curFrame, this.totalFrame);
    imageMode(CENTER);
    image(this.image[ser], this.px, this.py);
  }
// text the edage 
  isDead() {
    if (this.px < 0) {
      return true;
    } else {
      return false;
    }
  }
//move by the x position 
  update() {
    this.px -= this.speed;
  }
//new particle 
  birth(x, y) {
    this.curFrame = round(random(0, this.totalFrame));
    this.px = x;
    this.py = y;
  }

}
//the class of particle system
class ParticleSystem {
  constructor(image) {
    this.image = image;
    this.Particle = Particle; // Refer to the constructor function of particle class
    this.partArray = []; // An array holding particles
    this.probability = 0.4; // Determine the probability of emitting a particle in each frame
    this.num = 50; // The maximum number of particles in partArray
  }

  emit() {
    if (this.partArray.length < this.num) {
      if (random() < this.probability) {
        let particle = new this.Particle(this.image);
        particle.birth(width, random(0, height));
        this.partArray.push(particle);
      }
    }
  }

  remove() {
    for (let i in this.partArray) {
      if (this.partArray[i].isDead()) {
        this.partArray.splice(i, 1);
      }
    }
  }

  update() {
    for (let i in this.partArray) {
      this.partArray[i].update();
    }
  }

  show() {
    for (let i in this.partArray) {
      this.partArray[i].show();
    }
  }

  run() {
    this.emit();
    this.update();
    this.show();
    this.remove();
  }

}

// Subclasses of Particle and ParticleSystem

class Star extends Particle {
  constructor(image) {
    super(image);
    this.speed = 24;
  }
}
//
class StarSystem extends ParticleSystem {
  constructor(image) {
    super(image);
    this.Particle = Star;
    this.num = 40;
  }
}
// rainbow part 
class Rainbow extends Particle {
  constructor(image) {
    super(image);
    this.speed = 8;
  }
//fowlling the fish position(px,py)
  show() {
    imageMode(CENTER);
    image(this.image[0], this.px, this.py);
  }
}

class RainbowSystem extends ParticleSystem {
  constructor(image) {
    super(image);
    this.num = 50;
  }

  emit(x, y) {
    if (this.partArray.length < this.num) {
      let rainbow = new Rainbow(this.image);
      rainbow.px = x;
      rainbow.py = y;
      this.partArray.push(rainbow);
    }
  }

}

// coin system 
class Coin extends Particle {
  constructor(image) {
    super(image);
    this.speed = 30;
  }
//text the distance bewteen coin and fish
  isCollected() {
    if (this.px < ncat.px + 75 && this.px > ncat.px - 75 && this.py < ncat.py + 75 && this.py > ncat.py - 75) {
      return true;
    }
    else {
      return false;
    }
  }
}

class CoinSystem extends ParticleSystem {
  constructor(image) {
    super(image);
    this.Particle = Coin;
    this.num = 3;
    this.collectedCoins = 0;
    this.probability = 0.1;
  }

  collectCoins() {
    for (let i in this.partArray) {
      if (this.partArray[i].isCollected()) {
        this.collectedCoins ++;
        this.partArray.splice(i, 1);
      }
    }
  }

  run() {
    super.run();
    this.collectCoins();
  }
}
//import stone image
class Stone extends Particle {
  constructor(image) {
    super(image);
    this.speed = 30;
  }

  hit() {
    if (ncat.vulnerable) {
      if (this.px < ncat.px + 50 && this.px > ncat.px - 50 && this.py < ncat.py + 50 && this.py > ncat.py - 50) {
        ncat.life --;
        ncat.getHurt();
      }
    }
  }
}

class StoneSystem extends ParticleSystem {
  constructor(image) {
    super(image);
    this.Particle = Stone;
    this.num = 5;
    this.probability = 0.2;
  }

  hit() {
    for (let i in this.partArray) {
      this.partArray[i].hit();
    }
  }

  run() {
    super.run();
    this.hit();
  }
}
