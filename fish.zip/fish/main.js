/* jshint esversion:6 */
// Nyan Cat JavaScript with p5.js

// System objects
var ncat; // Nyan Cat
var ps; // Particle System
var ss; // Star System
var rsys; // Rainbow System
var cs; // Coin System
var sts; // Stone System
var ui; // Game UI

// Variables for images, fonts & sounds
var bgm; // Background music (BRAINWASHING)
var font; // Display font
var catImg = []; // Nyan Cat images
var rbImg = []; // Rainbow texture images
var starImg = []; // Glowing star images
var coinImg = []; // Coins
var stoneImg = []; // Stones
var catIcon; // Nyan Cat icon displayed on the HUD
var coinIcon; // Coin count icon displayed on the HUD


var serial; // variable to hold an instance of the serialport library
var portName = '/dev/cu.usbmodem14411'; // fill in your serial port name here
var inData; // for incoming serial data
var inByte;
var byteCount = 0;
var output = 0;
var options = {
  baudrate: 9600
};

function preload() {
  bgm = loadSound("asset/bgm.mp3");
  font = loadFont("asset/voltergoldfish.ttf");
  catIcon = loadImage("asset/catIcon.png");
  coinIcon = loadImage("asset/coinIcon.png");
  rbImg[0] = loadImage("asset/RainbowImg.png");

  for (let i = 0; i < 12; i++) {
    catImg[i] = loadImage("asset/catImg/catImg" + i + ".png");
  }

  for (let i = 0; i < 6; i++) {
    starImg[i] = loadImage("asset/starImg/star" + i + ".png");
  }

  for (let i = 0; i < 8; i++) {
    coinImg[i] = loadImage("asset/coinImg/Coin_" + i + ".png");
  }

  for (let i = 0; i < 72; i++) {
    stoneImg[i] = loadImage("asset/stoneImg/Stone_" + i + ".png");
  }
}

function setup() {
  createCanvas(window.innerWidth, window.innerHeight);
  frameRate(30);

  ncat = new NyanCat();
  ss = new StarSystem(starImg);
  rsys = new RainbowSystem(rbImg);
  cs = new CoinSystem(coinImg);
  sts = new StoneSystem(stoneImg);
  ui = new GameUI();


    serial = new p5.SerialPort(); // make a new instance of the serialport library
  serial.on('data', serialEvent); // callback for when new data arrives
  serial.on('error', serialError); // callback for errors

  serial.open(portName, options); // open a serial port
  serial.clear();
}

function draw() {
  background(9, 37, 77);
  textFont(font);
  fill(255);

  ui.run();

 fill(255);
  // display the incoming serial data as a string:
  var displayString = "inByte: " + inByte + "\t Byte count: " + byteCount;
  displayString += "  available: " + serial.available();
  //text(displayString, 30, 60);

}

function serRound(ser, step) {
  while (ser >= step) {
    ser -= step;
  }
  return ser;
}

function serialEvent() {
  // read a byte from the serial port:
  inByte = int(serial.read());
  byteCount++;
}

function serialError(err) {
  console.log('Something went wrong with the serial port. ' + err);
}
