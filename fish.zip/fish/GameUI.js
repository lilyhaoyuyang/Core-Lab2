/* jshint esversion:6 */
// Game UI

/* Three Stages :
 * START
 * GAMEPLAY
 * GAMEOVER
 */

 class GameUI {
   constructor() {
     this.state = "START";
     this.bgm = bgm;
     this.bgmFirstPlay = true;
   }

   run() {
     if (this.state == "START") {
       this.start();
     }
     else if (this.state == "GAMEPLAY") {
       this.gamePlay();
     }
     else if (this.state == "GAMEOVER") {
       this.gameOver();
     }
   }

   start() {
     ss.run(); // Stars show as background

     // Start Interface
     textSize(100); // Title
     textAlign(CENTER, CENTER);
     text("Fish", width/2, height/4);

     textSize(30); // instructions
     text("Collect coins and dodge stones\n\nPress ENTER to start", width/2, height*0.6);

     if (keyIsPressed) {
       if (keyCode == ENTER) {
         this.state = "GAMEPLAY";
       }
     }
   }

   gamePlay() {
     if (this.bgmFirstPlay) { // Play bgm
       this.bgm.play();
       this.bgmFirstPlay = false;
     }
     else if (!this.bgm.isPlaying()) { // Loop
       this.bgm.jump(4.055);
     }

     ss.run();// Several systems run
     cs.run();
     sts.run();
     ncat.control();
     ncat.show();

     // HUD
     imageMode(CENTER); // Show cat life
     image(catIcon, 40, 40);
     textAlign(CENTER, CENTER);
     textSize(40);
     text(ncat.life, 125, 50);

     image(coinIcon, width - 40, 40); // Show collected coins
     textAlign(RIGHT, CENTER);
     text(cs.collectedCoins, width - 90, 40);

     if (ncat.life < 1) {
       this.state = "GAMEOVER";
       this.bgmFirstPlay = true;
       this.bgm.stop();
     }
   }

   gameOver() {
     ss.run(); // Stars show as background

     // Game over Interface
     textAlign(CENTER, CENTER); // Game over title
     textSize(100);
     text("GAME OVER", width/2, height/4);
     textSize(30); // instructions
     text("Fish is dead\n\nPress ENTER to play again", width/2, height*0.6);
     image(coinIcon, width - 40, 40); // Show collected coins
     textAlign(RIGHT, CENTER);
     text(cs.collectedCoins, width - 90, 40);

     if (keyIsPressed) {
       if (keyCode == ENTER) {
         this.state = "GAMEPLAY";
         ncat = new NyanCat(); // Initiate game elements
         rsys = new RainbowSystem(rbImg);
         cs = new CoinSystem(coinImg);
         sts = new StoneSystem(stoneImg);
       }
     }
   }
 }
