// NyanCat class
/* jshint esversion:6 */

class NyanCat {
  constructor() {
    this.life = 5;
    this.px = width/4;
    this.py = height/2;
    this.image = catImg;
    this.vulnerable = true;
    this.hit = false;
    this.hitFrameCount = 0;
    this.posOff = 30;
  }

  show() {
    push();
    let curFrame = serRound(frameCount, 12);
    if (this.hit) { // If Nyan cat is hit, it'll be resistant to stones for 1 sec.
      tint(255, 70, 70); // Show cat in a special color
      this.hitFrameCount ++;
      if (this.hitFrameCount > 30) {
        this.hit = false;
        this.hitFrameCount = 0;
        this.vulnerable = true;
      }
    }
    imageMode(CENTER);
    image(this.image[int(curFrame/2.5)], this.px, this.py);
    pop();
  }
// text the edge
  checkEdges() {
    if (this.py > height) {
      this.py = height;
    }
    else if (this.py < 0) {
      this.py = 0;
    }
  }
//control the fish
  control() {
    for (let t = 0; t < 4; t++) {
     // if (keyIsPressed) {
        //if (key == 'w' || key == 'W') {
         // this.py -= this.posOff/4;
       // }
        //else if (key == 's' || key == 'S') {
         // this.py += this.posOff/4;
       // }
     // }
     this.py = 780-5*inByte;
      if (this.py > height) {
      this.py = height;
    }
    else if (this.py < 0) {
      this.py = 0;
    }
      this.checkEdges();
      rsys.emit(this.px, this.py + 2 * round(2 * sin(frameCount / 2) ) );
      rsys.remove();
      rsys.update();
    }
    rsys.show();
  }
//stone
  getHurt() {
    this.vulnerable = false;
    this.hit = true;
  }
}
